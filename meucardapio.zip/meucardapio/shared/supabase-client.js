// =========================================================
// Cliente Supabase único, reutilizado por admin/ e menu/
// Carregue este arquivo DEPOIS do SDK do Supabase via CDN:
// <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
// =========================================================

// Substitua pelas suas credenciais do projeto Supabase.
// A anon key é pública por natureza (protegida pelas RLS), pode ficar no front-end.
const SUPABASE_URL = "https://SEU-PROJETO.supabase.co";
const SUPABASE_ANON_KEY = "SUA_ANON_KEY_AQUI";

// Instância única (singleton) usada em toda a aplicação
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
