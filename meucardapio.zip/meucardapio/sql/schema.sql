-- =========================================================
-- MEUCARDÁPIO — SCHEMA SUPABASE (PostgreSQL)
-- Arquitetura multi-tenant: 1 conta de usuário = 1 restaurante
-- =========================================================

-- Extensão para gerar UUIDs
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------
-- TABELA: restaurants
-- Guarda os dados do tenant + configurações visuais/contato
-- ---------------------------------------------------------
create table public.restaurants (
  id             uuid primary key default gen_random_uuid(),
  owner_id       uuid not null references auth.users(id) on delete cascade,
  slug           text not null unique,          -- ex: "pizzariadojoao"
  nome           text not null,
  descricao      text,
  whatsapp       text,                          -- ex: "5512999999999"
  logo_url       text,
  banner_url     text,
  cor_primaria   text default '#c62828',
  cor_secundaria text default '#212121',
  cor_fundo      text default '#fafafa',
  fonte          text default 'Poppins',
  publicado      boolean not null default false, -- controla se o cardápio está no ar
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

-- slug só pode ter letras minúsculas, números e hífen
alter table public.restaurants
  add constraint slug_format check (slug ~ '^[a-z0-9-]+$');

create index idx_restaurants_slug on public.restaurants (slug);
create index idx_restaurants_owner on public.restaurants (owner_id);

-- ---------------------------------------------------------
-- TABELA: categories
-- ---------------------------------------------------------
create table public.categories (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  nome          text not null,
  ordem         integer not null default 0,
  ativo         boolean not null default true,
  created_at    timestamptz not null default now()
);

create index idx_categories_restaurant on public.categories (restaurant_id);

-- ---------------------------------------------------------
-- TABELA: products
-- ---------------------------------------------------------
create table public.products (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  category_id   uuid references public.categories(id) on delete set null,
  nome          text not null,
  descricao     text,
  preco         numeric(10,2) not null default 0,
  foto_url      text,
  ordem         integer not null default 0,
  ativo         boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index idx_products_restaurant on public.products (restaurant_id);
create index idx_products_category on public.products (category_id);

-- ---------------------------------------------------------
-- Trigger: manter updated_at sempre atualizado
-- ---------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_restaurants_updated_at
before update on public.restaurants
for each row execute function public.set_updated_at();

create trigger trg_products_updated_at
before update on public.products
for each row execute function public.set_updated_at();

-- =========================================================
-- ROW LEVEL SECURITY (RLS)
-- Regra de ouro:
--  - Dono (owner_id = auth.uid()) enxerga e edita TUDO do seu restaurante,
--    mesmo que não esteja publicado (precisa editar antes de publicar).
--  - Público (anon) só enxerga dados de restaurantes com publicado = true,
--    e apenas leitura (select).
-- =========================================================

alter table public.restaurants enable row level security;
alter table public.categories  enable row level security;
alter table public.products    enable row level security;

-- ---------- RESTAURANTS ----------

-- Leitura pública: só restaurante publicado
create policy "public_read_published_restaurant"
on public.restaurants for select
to anon
using (publicado = true);

-- Leitura pelo dono: sempre, publicado ou não
create policy "owner_read_own_restaurant"
on public.restaurants for select
to authenticated
using (owner_id = auth.uid());

-- Inserção: só o próprio usuário autenticado, como owner
create policy "owner_insert_own_restaurant"
on public.restaurants for insert
to authenticated
with check (owner_id = auth.uid());

-- Update: só o dono, e só no próprio registro
create policy "owner_update_own_restaurant"
on public.restaurants for update
to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

-- Delete: só o dono
create policy "owner_delete_own_restaurant"
on public.restaurants for delete
to authenticated
using (owner_id = auth.uid());

-- ---------- CATEGORIES ----------

-- Público só lê categorias de restaurante publicado
create policy "public_read_categories_of_published"
on public.categories for select
to anon
using (
  exists (
    select 1 from public.restaurants r
    where r.id = categories.restaurant_id
      and r.publicado = true
  )
);

-- Dono lê/edita categorias do seu restaurante
create policy "owner_read_own_categories"
on public.categories for select
to authenticated
using (
  exists (
    select 1 from public.restaurants r
    where r.id = categories.restaurant_id
      and r.owner_id = auth.uid()
  )
);

create policy "owner_write_own_categories"
on public.categories for insert
to authenticated
with check (
  exists (
    select 1 from public.restaurants r
    where r.id = categories.restaurant_id
      and r.owner_id = auth.uid()
  )
);

create policy "owner_update_own_categories"
on public.categories for update
to authenticated
using (
  exists (select 1 from public.restaurants r where r.id = categories.restaurant_id and r.owner_id = auth.uid())
)
with check (
  exists (select 1 from public.restaurants r where r.id = categories.restaurant_id and r.owner_id = auth.uid())
);

create policy "owner_delete_own_categories"
on public.categories for delete
to authenticated
using (
  exists (select 1 from public.restaurants r where r.id = categories.restaurant_id and r.owner_id = auth.uid())
);

-- ---------- PRODUCTS ----------

create policy "public_read_products_of_published"
on public.products for select
to anon
using (
  exists (
    select 1 from public.restaurants r
    where r.id = products.restaurant_id
      and r.publicado = true
  )
);

create policy "owner_read_own_products"
on public.products for select
to authenticated
using (
  exists (select 1 from public.restaurants r where r.id = products.restaurant_id and r.owner_id = auth.uid())
);

create policy "owner_write_own_products"
on public.products for insert
to authenticated
with check (
  exists (select 1 from public.restaurants r where r.id = products.restaurant_id and r.owner_id = auth.uid())
);

create policy "owner_update_own_products"
on public.products for update
to authenticated
using (
  exists (select 1 from public.restaurants r where r.id = products.restaurant_id and r.owner_id = auth.uid())
)
with check (
  exists (select 1 from public.restaurants r where r.id = products.restaurant_id and r.owner_id = auth.uid())
);

create policy "owner_delete_own_products"
on public.products for delete
to authenticated
using (
  exists (select 1 from public.restaurants r where r.id = products.restaurant_id and r.owner_id = auth.uid())
);

-- =========================================================
-- STORAGE (fotos de produtos, logo, banner)
-- Criar bucket "cardapio-imagens" no painel do Supabase (público para leitura)
-- Policies de storage (rodar depois de criar o bucket):
-- =========================================================
-- insert into storage.buckets (id, name, public) values ('cardapio-imagens', 'cardapio-imagens', true)
-- on conflict (id) do nothing;

create policy "public_read_storage_imagens"
on storage.objects for select
to anon
using (bucket_id = 'cardapio-imagens');

create policy "owner_upload_storage_imagens"
on storage.objects for insert
to authenticated
with check (bucket_id = 'cardapio-imagens' and owner = auth.uid());

create policy "owner_update_storage_imagens"
on storage.objects for update
to authenticated
using (bucket_id = 'cardapio-imagens' and owner = auth.uid());

create policy "owner_delete_storage_imagens"
on storage.objects for delete
to authenticated
using (bucket_id = 'cardapio-imagens' and owner = auth.uid());
