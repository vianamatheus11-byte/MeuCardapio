// =========================================================
// CONFIGURAÇÕES DO RESTAURANTE
// Preenche o formulário com os dados atuais e salva alterações.
// =========================================================

function preencherFormConfig(r) {
  document.getElementById("cfg-nome").value = r.nome || "";
  document.getElementById("cfg-descricao").value = r.descricao || "";
  document.getElementById("cfg-slug").value = r.slug || "";
  document.getElementById("cfg-whatsapp").value = r.whatsapp || "";
  document.getElementById("cfg-logo").value = r.logo_url || "";
  document.getElementById("cfg-banner").value = r.banner_url || "";
  document.getElementById("cfg-cor-primaria").value = r.cor_primaria || "#c62828";
  document.getElementById("cfg-cor-secundaria").value = r.cor_secundaria || "#212121";
  document.getElementById("cfg-cor-fundo").value = r.cor_fundo || "#fafafa";
}

document.getElementById("form-config").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("config-msg");
  msg.hidden = true;

  const arquivoLogo = document.getElementById("cfg-logo-file").files[0];
  const arquivoBanner = document.getElementById("cfg-banner-file").files[0];

  let logo_url = document.getElementById("cfg-logo").value.trim() || null;
  let banner_url = document.getElementById("cfg-banner").value.trim() || null;

  if (arquivoLogo) {
    const url = await uploadFoto(arquivoLogo, "logo");
    if (url) logo_url = url;
  }
  if (arquivoBanner) {
    const url = await uploadFoto(arquivoBanner, "banner");
    if (url) banner_url = url;
  }

  const novoSlug = document.getElementById("cfg-slug").value.trim().toLowerCase();

  const payload = {
    nome: document.getElementById("cfg-nome").value.trim(),
    descricao: document.getElementById("cfg-descricao").value.trim(),
    slug: novoSlug,
    whatsapp: document.getElementById("cfg-whatsapp").value.trim(),
    logo_url,
    banner_url,
    cor_primaria: document.getElementById("cfg-cor-primaria").value,
    cor_secundaria: document.getElementById("cfg-cor-secundaria").value,
    cor_fundo: document.getElementById("cfg-cor-fundo").value,
  };

  const { data, error } = await supabaseClient
    .from("restaurants")
    .update(payload)
    .eq("id", currentRestaurant.id)
    .select()
    .single();

  if (error) {
    msg.textContent = error.code === "23505"
      ? "Esse link (slug) já está em uso por outro restaurante."
      : "Erro ao salvar: " + error.message;
    msg.className = "msg erro";
    msg.hidden = false;
    return;
  }

  currentRestaurant = data;
  atualizarLinkPublico();
  msg.textContent = "Configurações salvas com sucesso!";
  msg.className = "msg ok";
  msg.hidden = false;
});

document.addEventListener("restaurante-pronto", (e) => {
  preencherFormConfig(e.detail);
});
