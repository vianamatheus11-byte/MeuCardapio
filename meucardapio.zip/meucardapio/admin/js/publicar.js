// =========================================================
// PUBLICAÇÃO
// Ao clicar em "Publicar", NÃO gera nenhum arquivo novo.
// Apenas atualiza o campo `publicado` para true no registro
// do restaurante. O motor único (/menu/:slug) passa a servir
// o cardápio a partir desse momento, pois a RLS de leitura
// pública depende exatamente desse campo.
// =========================================================

function urlPublica() {
  return `${window.location.origin}/menu/${currentRestaurant.slug}`;
}

function atualizarLinkPublico() {
  const link = document.getElementById("link-publico");
  const btn = document.getElementById("btn-publicar");

  link.href = urlPublica();
  link.hidden = !currentRestaurant.publicado;
  btn.textContent = currentRestaurant.publicado ? "Despublicar cardápio" : "Publicar cardápio";
}

document.getElementById("btn-publicar").addEventListener("click", async () => {
  const novoStatus = !currentRestaurant.publicado;

  if (novoStatus) {
    // Validações mínimas antes de publicar
    if (!currentRestaurant.slug) {
      return alert("Configure o link (slug) do restaurante antes de publicar.");
    }
    const temProdutoAtivo = produtosCache.some((p) => p.ativo);
    if (!temProdutoAtivo) {
      return alert("Adicione pelo menos um produto visível antes de publicar.");
    }
  }

  const { data, error } = await supabaseClient
    .from("restaurants")
    .update({ publicado: novoStatus }) // <-- única mudança no banco
    .eq("id", currentRestaurant.id)
    .select()
    .single();

  if (error) {
    return alert("Erro ao atualizar publicação: " + error.message);
  }

  currentRestaurant = data;
  atualizarLinkPublico();
  alert(novoStatus ? "Cardápio publicado com sucesso!" : "Cardápio despublicado.");
});

document.addEventListener("restaurante-pronto", atualizarLinkPublico);
