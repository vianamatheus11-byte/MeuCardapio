// =========================================================
// CATEGORIAS — CRUD (Create, Read, Update, Delete)
// =========================================================

let categoriasCache = [];

async function carregarCategorias() {
  const { data, error } = await supabaseClient
    .from("categories")
    .select("*")
    .eq("restaurant_id", currentRestaurant.id)
    .order("ordem", { ascending: true });

  if (error) {
    console.error(error);
    return;
  }
  categoriasCache = data;
  renderCategorias();
  preencherSelectCategoriaNoProduto(); // definido em produtos.js
}

function renderCategorias() {
  const lista = document.getElementById("lista-categorias");
  lista.innerHTML = "";

  categoriasCache.forEach((cat) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <span>${escapeHtmlAdmin(cat.nome)} ${cat.ativo ? "" : "(oculta)"}</span>
      <span class="item-acoes">
        <button data-id="${cat.id}" class="btn-editar-categoria">Editar</button>
        <button data-id="${cat.id}" class="btn-excluir-categoria">Excluir</button>
      </span>
    `;
    lista.appendChild(li);
  });

  lista.querySelectorAll(".btn-editar-categoria").forEach((btn) =>
    btn.addEventListener("click", () => abrirModalCategoria(btn.dataset.id))
  );
  lista.querySelectorAll(".btn-excluir-categoria").forEach((btn) =>
    btn.addEventListener("click", () => excluirCategoria(btn.dataset.id))
  );
}

function escapeHtmlAdmin(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function abrirModalCategoria(id) {
  const categoria = categoriasCache.find((c) => c.id === id) || {};

  abrirModal({
    titulo: id ? "Editar categoria" : "Nova categoria",
    corpoHtml: `
      <input type="text" id="modal-cat-nome" placeholder="Nome da categoria" value="${categoria.nome || ""}" />
      <label style="display:flex;align-items:center;gap:8px;">
        <input type="checkbox" id="modal-cat-ativo" ${categoria.ativo === false ? "" : "checked"} />
        Categoria visível no cardápio
      </label>
    `,
    aoSalvar: async () => {
      const nome = document.getElementById("modal-cat-nome").value.trim();
      const ativo = document.getElementById("modal-cat-ativo").checked;
      if (!nome) return alert("Informe o nome da categoria.");

      if (id) {
        const { error } = await supabaseClient
          .from("categories")
          .update({ nome, ativo })
          .eq("id", id);
        if (error) return alert("Erro ao salvar: " + error.message);
      } else {
        const { error } = await supabaseClient.from("categories").insert({
          restaurant_id: currentRestaurant.id,
          nome,
          ativo,
          ordem: categoriasCache.length,
        });
        if (error) return alert("Erro ao criar: " + error.message);
      }
      await carregarCategorias();
    },
  });
}

async function excluirCategoria(id) {
  if (!confirm("Excluir esta categoria? Os produtos vinculados ficarão sem categoria.")) return;
  const { error } = await supabaseClient.from("categories").delete().eq("id", id);
  if (error) return alert("Erro ao excluir: " + error.message);
  await carregarCategorias();
  await carregarProdutos(); // atualiza pois category_id pode ter mudado
}

document.getElementById("btn-nova-categoria").addEventListener("click", () => abrirModalCategoria(null));

document.addEventListener("restaurante-pronto", carregarCategorias);
