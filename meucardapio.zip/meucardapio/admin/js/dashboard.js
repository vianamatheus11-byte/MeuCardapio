// =========================================================
// DASHBOARD — navegação entre abas + modal genérico
// =========================================================

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add("active");
  });
});
// Ativa a primeira aba por padrão
document.querySelector(".tab-panel").classList.add("active");

// ---- Modal genérico ----
const modalOverlay = document.getElementById("modal");
const modalTitulo = document.getElementById("modal-titulo");
const modalCorpo = document.getElementById("modal-corpo");
const modalBtnSalvar = document.getElementById("modal-salvar");
const modalBtnCancelar = document.getElementById("modal-cancelar");

let onSalvarAtual = null;

function abrirModal({ titulo, corpoHtml, aoSalvar }) {
  modalTitulo.textContent = titulo;
  modalCorpo.innerHTML = corpoHtml;
  onSalvarAtual = aoSalvar;
  modalOverlay.hidden = false;
}

function fecharModal() {
  modalOverlay.hidden = true;
  modalCorpo.innerHTML = "";
  onSalvarAtual = null;
}

modalBtnCancelar.addEventListener("click", fecharModal);

modalBtnSalvar.addEventListener("click", async () => {
  if (!onSalvarAtual) return;
  modalBtnSalvar.disabled = true;
  try {
    await onSalvarAtual();
    fecharModal();
  } finally {
    modalBtnSalvar.disabled = false;
  }
});
