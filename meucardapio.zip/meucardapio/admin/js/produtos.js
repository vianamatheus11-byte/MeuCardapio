// =========================================================
// PRODUTOS — CRUD + upload de foto para o Supabase Storage
// =========================================================

let produtosCache = [];

async function carregarProdutos() {
  const { data, error } = await supabaseClient
    .from("products")
    .select("*")
    .eq("restaurant_id", currentRestaurant.id)
    .order("ordem", { ascending: true });

  if (error) {
    console.error(error);
    return;
  }
  produtosCache = data;
  renderProdutos();
}

function renderProdutos() {
  const lista = document.getElementById("lista-produtos");
  lista.innerHTML = "";

  produtosCache.forEach((prod) => {
    const categoria = categoriasCache.find((c) => c.id === prod.category_id);
    const li = document.createElement("li");
    li.innerHTML = `
      <span>${escapeHtmlAdmin(prod.nome)} — R$ ${Number(prod.preco).toFixed(2)}
        ${categoria ? `<small>(${escapeHtmlAdmin(categoria.nome)})</small>` : ""}
        ${prod.ativo ? "" : " (oculto)"}
      </span>
      <span class="item-acoes">
        <button data-id="${prod.id}" class="btn-editar-produto">Editar</button>
        <button data-id="${prod.id}" class="btn-excluir-produto">Excluir</button>
      </span>
    `;
    lista.appendChild(li);
  });

  lista.querySelectorAll(".btn-editar-produto").forEach((btn) =>
    btn.addEventListener("click", () => abrirModalProduto(btn.dataset.id))
  );
  lista.querySelectorAll(".btn-excluir-produto").forEach((btn) =>
    btn.addEventListener("click", () => excluirProduto(btn.dataset.id))
  );
}

function preencherSelectCategoriaNoProduto() {
  // usado dentro do modal, gerado dinamicamente — ver montarOpcoesCategorias()
}

function montarOpcoesCategorias(selecionadaId) {
  return categoriasCache
    .map((c) => `<option value="${c.id}" ${c.id === selecionadaId ? "selected" : ""}>${escapeHtmlAdmin(c.nome)}</option>`)
    .join("");
}

async function uploadFoto(file, pastaPrefixo) {
  const nomeArquivo = `${currentRestaurant.id}/${pastaPrefixo}-${Date.now()}-${file.name}`;
  const { error } = await supabaseClient.storage
    .from("cardapio-imagens")
    .upload(nomeArquivo, file, { upsert: true });

  if (error) {
    alert("Erro ao enviar imagem: " + error.message);
    return null;
  }

  const { data } = supabaseClient.storage.from("cardapio-imagens").getPublicUrl(nomeArquivo);
  return data.publicUrl;
}

function abrirModalProduto(id) {
  const produto = produtosCache.find((p) => p.id === id) || {};

  abrirModal({
    titulo: id ? "Editar produto" : "Novo produto",
    corpoHtml: `
      <input type="text" id="modal-prod-nome" placeholder="Nome do produto" value="${produto.nome || ""}" />
      <textarea id="modal-prod-descricao" placeholder="Descrição" rows="2">${produto.descricao || ""}</textarea>
      <input type="number" id="modal-prod-preco" placeholder="Preço (ex: 29.90)" step="0.01" value="${produto.preco || ""}" />
      <select id="modal-prod-categoria">
        <option value="">Sem categoria</option>
        ${montarOpcoesCategorias(produto.category_id)}
      </select>
      <input type="file" id="modal-prod-foto" accept="image/*" />
      ${produto.foto_url ? `<img src="${produto.foto_url}" style="width:60px;height:60px;border-radius:8px;object-fit:cover;">` : ""}
      <label style="display:flex;align-items:center;gap:8px;">
        <input type="checkbox" id="modal-prod-ativo" ${produto.ativo === false ? "" : "checked"} />
        Produto visível no cardápio
      </label>
    `,
    aoSalvar: async () => {
      const nome = document.getElementById("modal-prod-nome").value.trim();
      const descricao = document.getElementById("modal-prod-descricao").value.trim();
      const preco = parseFloat(document.getElementById("modal-prod-preco").value || "0");
      const category_id = document.getElementById("modal-prod-categoria").value || null;
      const ativo = document.getElementById("modal-prod-ativo").checked;
      const arquivoFoto = document.getElementById("modal-prod-foto").files[0];

      if (!nome) return alert("Informe o nome do produto.");

      let foto_url = produto.foto_url || null;
      if (arquivoFoto) {
        const url = await uploadFoto(arquivoFoto, "produto");
        if (url) foto_url = url;
      }

      const payload = { nome, descricao, preco, category_id, ativo, foto_url };

      if (id) {
        const { error } = await supabaseClient.from("products").update(payload).eq("id", id);
        if (error) return alert("Erro ao salvar: " + error.message);
      } else {
        const { error } = await supabaseClient.from("products").insert({
          ...payload,
          restaurant_id: currentRestaurant.id,
          ordem: produtosCache.length,
        });
        if (error) return alert("Erro ao criar: " + error.message);
      }
      await carregarProdutos();
    },
  });
}

async function excluirProduto(id) {
  if (!confirm("Excluir este produto?")) return;
  const { error } = await supabaseClient.from("products").delete().eq("id", id);
  if (error) return alert("Erro ao excluir: " + error.message);
  await carregarProdutos();
}

document.getElementById("btn-novo-produto").addEventListener("click", () => abrirModalProduto(null));

document.addEventListener("restaurante-pronto", carregarProdutos);
