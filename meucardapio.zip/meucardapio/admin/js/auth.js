// =========================================================
// AUTENTICAÇÃO
// - Login via Supabase Auth (email/senha)
// - Ao logar, garante que existe um restaurante vinculado ao owner_id
//   (cria automaticamente no primeiro acesso, com slug provisório)
// - Protege o painel: só renderiza se houver sessão ativa
// =========================================================

let currentUser = null;
let currentRestaurant = null; // objeto do restaurante do usuário logado, cacheado em memória

const telaLogin = document.getElementById("tela-login");
const telaPainel = document.getElementById("tela-painel");

function slugAleatorio() {
  return "restaurante-" + Math.random().toString(36).slice(2, 8);
}

// Busca (ou cria) o restaurante do usuário logado
async function obterOuCriarRestaurante(user) {
  const { data: existente, error } = await supabaseClient
    .from("restaurants")
    .select("*")
    .eq("owner_id", user.id)
    .maybeSingle();

  if (error) {
    console.error("Erro ao buscar restaurante:", error);
    return null;
  }

  if (existente) return existente;

  // Primeiro acesso: cria um restaurante rascunho para esse usuário
  const { data: novo, error: erroCriar } = await supabaseClient
    .from("restaurants")
    .insert({
      owner_id: user.id,
      slug: slugAleatorio(),
      nome: "Meu Restaurante",
      publicado: false,
    })
    .select()
    .single();

  if (erroCriar) {
    console.error("Erro ao criar restaurante inicial:", erroCriar);
    return null;
  }
  return novo;
}

async function iniciarSessaoAutenticada(user) {
  currentUser = user;
  currentRestaurant = await obterOuCriarRestaurante(user);

  if (!currentRestaurant) {
    alert("Não foi possível carregar os dados do seu restaurante. Tente novamente.");
    await supabaseClient.auth.signOut();
    return;
  }

  telaLogin.hidden = true;
  telaPainel.hidden = false;

  // Dispara evento para os outros módulos (categorias, produtos, config, publicar)
  document.dispatchEvent(new CustomEvent("restaurante-pronto", { detail: currentRestaurant }));
}

async function verificarSessaoExistente() {
  const { data } = await supabaseClient.auth.getSession();
  if (data.session?.user) {
    await iniciarSessaoAutenticada(data.session.user);
  }
}

document.getElementById("form-login").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const senha = document.getElementById("login-senha").value;
  const erroEl = document.getElementById("login-erro");
  erroEl.hidden = true;

  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password: senha });

  if (error) {
    erroEl.textContent = "E-mail ou senha inválidos.";
    erroEl.hidden = false;
    return;
  }

  await iniciarSessaoAutenticada(data.user);
});

document.getElementById("btn-logout").addEventListener("click", async () => {
  await supabaseClient.auth.signOut();
  window.location.reload();
});

// Reage a mudanças de sessão (ex: token expirado)
supabaseClient.auth.onAuthStateChange((event) => {
  if (event === "SIGNED_OUT") {
    telaLogin.hidden = false;
    telaPainel.hidden = true;
  }
});

verificarSessaoExistente();
