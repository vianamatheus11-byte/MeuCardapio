// =========================================================
// MOTOR DE CARDÁPIO — arquivo ÚNICO usado por TODOS os restaurantes.
// Fluxo:
//   1. Extrai o slug da URL (/menu/:slug)
//   2. Busca o restaurante no Supabase (só retorna se publicado = true,
//      graças à RLS — não precisamos nem checar isso manualmente aqui,
//      o banco já protege)
//   3. Busca categorias e produtos ativos desse restaurante
//   4. Aplica as cores/tema do restaurante via CSS variables
//   5. Renderiza o DOM dinamicamente
// =========================================================

const els = {
  loading: document.getElementById("loading-state"),
  notFound: document.getElementById("not-found-state"),
  root: document.getElementById("menu-root"),
  banner: document.getElementById("menu-banner"),
  logo: document.getElementById("menu-logo"),
  nome: document.getElementById("menu-nome"),
  descricao: document.getElementById("menu-descricao"),
  nav: document.getElementById("menu-categorias-nav"),
  container: document.getElementById("menu-categorias-container"),
  whatsapp: document.getElementById("whatsapp-float"),
  title: document.getElementById("page-title"),
  favicon: document.getElementById("page-favicon"),
};

function showState(state) {
  els.loading.hidden = state !== "loading";
  els.notFound.hidden = state !== "not-found";
  els.root.hidden = state !== "ready";
}

// 1. Extrai o slug a partir do path (funciona com o rewrite da Vercel:
// /menu/pizzariadojoao -> serve este arquivo, mas o path no browser continua /menu/pizzariadojoao)
function getSlugFromUrl() {
  const path = window.location.pathname; // ex: /menu/pizzariadojoao
  const parts = path.split("/").filter(Boolean); // ["menu", "pizzariadojoao"]
  const idx = parts.indexOf("menu");
  if (idx === -1 || !parts[idx + 1]) return null;
  return decodeURIComponent(parts[idx + 1]).toLowerCase();
}

function aplicarTema(restaurante) {
  const root = document.documentElement;
  root.style.setProperty("--cor-primaria", restaurante.cor_primaria || "#c62828");
  root.style.setProperty("--cor-secundaria", restaurante.cor_secundaria || "#212121");
  root.style.setProperty("--cor-fundo", restaurante.cor_fundo || "#fafafa");
  if (restaurante.fonte) {
    root.style.setProperty("--fonte", `'${restaurante.fonte}', sans-serif`);
  }
  els.title.textContent = restaurante.nome;
  if (restaurante.logo_url) els.favicon.href = restaurante.logo_url;
}

function renderHeader(restaurante) {
  els.nome.textContent = restaurante.nome;
  els.descricao.textContent = restaurante.descricao || "";

  if (restaurante.banner_url) {
    els.banner.src = restaurante.banner_url;
    els.banner.hidden = false;
  }
  if (restaurante.logo_url) {
    els.logo.src = restaurante.logo_url;
    els.logo.hidden = false;
  }
  if (restaurante.whatsapp) {
    const numero = restaurante.whatsapp.replace(/\D/g, "");
    els.whatsapp.href = `https://wa.me/${numero}?text=${encodeURIComponent(
      "Olá! Vi o cardápio de " + restaurante.nome + " e quero fazer um pedido."
    )}`;
    els.whatsapp.hidden = false;
  }
}

function formatarPreco(valor) {
  return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function renderCardapio(categorias, produtosPorCategoria) {
  els.nav.innerHTML = "";
  els.container.innerHTML = "";

  categorias.forEach((cat, index) => {
    const produtos = produtosPorCategoria[cat.id] || [];
    if (produtos.length === 0) return; // não mostra categoria vazia

    // Botão de navegação
    const btn = document.createElement("button");
    btn.textContent = cat.nome;
    btn.dataset.target = `cat-${cat.id}`;
    if (index === 0) btn.classList.add("active");
    btn.addEventListener("click", () => {
      document.getElementById(`cat-${cat.id}`).scrollIntoView({ behavior: "smooth", block: "start" });
      document.querySelectorAll(".categorias-nav button").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
    });
    els.nav.appendChild(btn);

    // Seção da categoria
    const secao = document.createElement("section");
    secao.className = "categoria-secao";
    secao.id = `cat-${cat.id}`;

    const titulo = document.createElement("h2");
    titulo.textContent = cat.nome;
    secao.appendChild(titulo);

    produtos.forEach((prod) => {
      const card = document.createElement("article");
      card.className = "produto-card";

      card.innerHTML = `
        ${prod.foto_url
          ? `<img class="produto-foto" src="${prod.foto_url}" alt="${escapeHtml(prod.nome)}" loading="lazy">`
          : `<div class="produto-foto"></div>`}
        <div class="produto-info">
          <h3>${escapeHtml(prod.nome)}</h3>
          ${prod.descricao ? `<p>${escapeHtml(prod.descricao)}</p>` : ""}
          <span class="produto-preco">${formatarPreco(prod.preco)}</span>
        </div>
      `;
      secao.appendChild(card);
    });

    els.container.appendChild(secao);
  });
}

// Proteção simples contra XSS ao injetar texto no innerHTML
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

async function carregarCardapio() {
  showState("loading");

  const slug = getSlugFromUrl();
  if (!slug) {
    showState("not-found");
    return;
  }

  // Busca o restaurante. A policy RLS "public_read_published_restaurant"
  // garante que só retorna algo se publicado = true — se não publicado,
  // vem vazio, e tratamos como "não encontrado" (não vaza a existência do rascunho).
  const { data: restaurante, error: restauranteError } = await supabaseClient
    .from("restaurants")
    .select("*")
    .eq("slug", slug)
    .eq("publicado", true)
    .single();

  if (restauranteError || !restaurante) {
    showState("not-found");
    return;
  }

  aplicarTema(restaurante);
  renderHeader(restaurante);

  // Busca categorias ativas
  const { data: categorias, error: categoriasError } = await supabaseClient
    .from("categories")
    .select("*")
    .eq("restaurant_id", restaurante.id)
    .eq("ativo", true)
    .order("ordem", { ascending: true });

  if (categoriasError) {
    showState("not-found");
    return;
  }

  // Busca produtos ativos
  const { data: produtos, error: produtosError } = await supabaseClient
    .from("products")
    .select("*")
    .eq("restaurant_id", restaurante.id)
    .eq("ativo", true)
    .order("ordem", { ascending: true });

  if (produtosError) {
    showState("not-found");
    return;
  }

  // Agrupa produtos por categoria
  const produtosPorCategoria = {};
  (produtos || []).forEach((p) => {
    if (!produtosPorCategoria[p.category_id]) produtosPorCategoria[p.category_id] = [];
    produtosPorCategoria[p.category_id].push(p);
  });

  renderCardapio(categorias || [], produtosPorCategoria);
  showState("ready");
}

carregarCardapio();
